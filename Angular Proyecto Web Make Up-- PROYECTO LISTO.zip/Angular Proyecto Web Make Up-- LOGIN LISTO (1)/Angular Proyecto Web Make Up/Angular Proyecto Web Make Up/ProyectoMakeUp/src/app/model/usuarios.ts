export interface Usuario{
    UsuarioID?: string;
    NombreUsuario?:   string;
    ApellidoUsuario?: string,
    Telefono?:        number;
    Correo?:     string;
    Contrasena?:   string;
    Token?: string;
}