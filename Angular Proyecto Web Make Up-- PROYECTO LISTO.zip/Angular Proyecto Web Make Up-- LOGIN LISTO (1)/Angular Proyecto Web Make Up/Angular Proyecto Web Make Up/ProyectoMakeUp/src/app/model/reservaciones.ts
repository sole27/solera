export interface Reservaciones{
    NumeroReservacion?: number;  
    FechaDeReservacion?: Date;     
    TipoCita?: string;           
    SolicitanteID?: number;
    Token?: string;
}

