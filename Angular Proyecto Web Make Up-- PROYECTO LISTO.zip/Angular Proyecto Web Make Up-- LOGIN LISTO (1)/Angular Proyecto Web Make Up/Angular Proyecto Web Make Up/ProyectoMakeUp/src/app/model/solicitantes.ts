export interface Solicitantes{
    SolicitanteID?: number;
    NombreSolicitante?: string;
    ApellidoSolicitante?: string;
    Telefono?: number;
    Correo?: string;
    Token?: string;
}