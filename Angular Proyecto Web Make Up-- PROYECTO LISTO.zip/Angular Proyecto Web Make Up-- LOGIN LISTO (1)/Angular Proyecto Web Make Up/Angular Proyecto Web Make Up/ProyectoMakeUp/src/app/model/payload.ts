export interface Payload {
    Rol: string;
    Correo: string;
    UsuarioID: number;
    iat: string;
    exp?: string;
  }